package com.timer.steps;

import com.timer.page.EggTimerPage;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.And;

public class EggTimerStep {

   private EggTimerPage eggTimerPage;
    public EggTimerStep(){
        eggTimerPage = new EggTimerPage();
    }
    @When("^Enter a time value as (\\d+) to start Timer$")
    public void enterATimeValueAsToStartTimer(int time) throws Throwable {
        this.eggTimerPage.enterTimeValue(time);
    }

    @Given("^verify user is on Egg timer website$")
    public void verifyUserIsOnEggTimerWebsite() throws Throwable {
        this.eggTimerPage.verifyUserIsOnEggTimerHomePage();
    }

    @And("^click on the start button$")
    public void clickOnTheStartButton() throws Throwable {
        this.eggTimerPage.clickOnButton("start");
    }

    @And("^verify timer is started$")
    public void verifyTimerIsStarted() throws Throwable {
        this.eggTimerPage.verifyTimerStarted();
    }

    @Then("^verify timer is decreasing by one second$")
    public void verifyTimerIsDecreasingByOneSecond() throws Throwable {
        this.eggTimerPage.verifyTimerFunctionality();
    }

    @And("^verify Time Expired! is displayed once time is completed$")
    public void verifyTimeExpiredIsDisplayedOnceTimeIsCompleted() throws Throwable {
        this.eggTimerPage.verifyAtTheEndTimeExpiredMessageIsDisplayed();
    }
}
