package com.timer.page;

import org.openqa.selenium.By;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;

import static com.timer.basecode.SeleniumCode.*;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.is;

public class EggTimerPage {
    private Logger logger = LoggerFactory.getLogger(EggTimerPage.class);
    private int userTimer = 0;


    public void enterTimeValue(int time) {
        setUserTimer(time);
        assertThat(verifyText(By.xpath("//*[@id=\"root\"]/div/div/div[2]/main/div[2]/p[1]")), is(equalTo("E.ggTimer is a simple countdown timer.")));
        enterText(By.id("EggTimer-start-time-input-text"), time + "");
        logger.info("Timer value is now entered in the text box - " + time);
    }


    public void verifyAtTheEndTimeExpiredMessageIsDisplayed() throws InterruptedException {
        checkAlert();
        acceptAlert();
        assertThat(verifyText(By.xpath("//*[@id=\"root\"]/div/main/div[1]/div/div[2]/p/span")), is(equalTo("Time Expired!")));
        logger.info("Check alert is displayed and accept the alert, once accepted verify text on the page i.e. Time Expired!!");
    }


    public void verifyTimerFunctionality() throws InterruptedException {
        Set<Integer> result = new HashSet<>();
        try {
            waitForElementToDisplayed(By.xpath("//*[@id=\"root\"]/div/main/div[1]/div/div[2]/p/span"));
            Set<Integer> set = new HashSet<Integer>();
            int valueFromUI = 0;
            for (int i = 0; i < getUserTimer(); i++) {
                valueFromUI = Integer.parseInt(verifyText(By.xpath("//*[@id=\"root\"]/div/main/div[1]/div/div[2]/p/span")).replaceAll("[a-z]", "").trim());
                set.add(valueFromUI);
                Thread.sleep(900L);
            }
            List<Integer> list = new ArrayList<>(set);
            list.sort(Collections.reverseOrder());
            result = new LinkedHashSet<>(list);

            int counter = Integer.parseInt(set.toArray()[set.size() - 1].toString());
            for (int value : result) {
                assertThat(value, is(equalTo(counter)));
                --counter;
            }
            logger.info("verified whether counter is working correct or not!!");
        } catch (AssertionError ae) {
            logger.error(ae.getMessage());
            logger.info(result.toString());
        }


    }


    public void verifyTimerStarted() {
        waitForElementToDisplayed(By.id("theme-select"));
        logger.info("Countdown timer page is now loaded!");

    }

    public void clickOnButton(String buttonName) {
        switch (buttonName.toLowerCase()) {
            case "start":
                buttonClick(By.xpath("//button[text()='Start']"));
                break;
        }
        logger.info(buttonName.toUpperCase() + " Button is now clicked");
    }


    public void verifyUserIsOnEggTimerHomePage() {
        assertThat(verifyText(By.xpath("//*[@id=\"root\"]/div/div/div[2]/main/div[2]/p[1]")), is(equalTo("E.ggTimer is a simple countdown timer.")));
    }

    private int getUserTimer() {
        return this.userTimer;
    }

    private void setUserTimer(int userTimer) {
        this.userTimer = userTimer;
    }
}
