package com.timer.basecode;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ResourceBundle;

public class SeleniumCode {

    private static WebDriver driver;
    private static Alert alert;
    private static WebDriverWait webDriverWait;
    private final String browser = System.getProperty("browser") == null || System.getProperty("browser").isEmpty() ? "chrome" : System.getProperty("browser");
    private final ResourceBundle resourceBundle = ResourceBundle.getBundle("config");
    private final Logger logger = LoggerFactory.getLogger(SeleniumCode.class);

    public static String verifyText(By locator) {
//        waitForElementToDisplayed(locator);
        return driver.findElement(locator).getText();
    }

    public static void enterText(By locator, String text) {
//        waitForElementToDisplayed(locator);
        driver.findElement(locator).sendKeys(text);
    }

    public static void buttonClick(By locator) {
//        waitForElementToDisplayed(locator);
        driver.findElement(locator).click();
    }

    public static void acceptAlert() {
        alert = driver.switchTo().alert();
        alert.accept();
    }

    public static void dismissAlert(){
        alert = driver.switchTo().alert();
        alert.dismiss();
    }

    public static void waitForElementToDisplayed(By locator) {
        webDriverWait = new WebDriverWait(driver, 20);
        webDriverWait.until(ExpectedConditions.presenceOfElementLocated(locator));
    }

    public static void checkAlert() {
        webDriverWait = new WebDriverWait(driver, 20);
        webDriverWait.until(ExpectedConditions.alertIsPresent());
    }

    @Before
    public void setup() {
        logger.info("Browser selected - " + browser);

        switch (browser.toLowerCase()) {
            case "chrome":
                System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "//src//main//java//com//timer//drivers//chromedriver.exe");
                ChromeOptions options = new ChromeOptions();
//                options.addArguments("--headless");
                driver = new ChromeDriver(options);
                break;
            case "firefox":
                driver = new FirefoxDriver();
                break;
            case "edge":
                System.setProperty("webdriver.edge.driver", System.getProperty("user.dir") + "//src//main//java//com//timer//drivers//msedgedriver.exe");
                driver = new EdgeDriver();
                break;
            default:
                throw new IllegalArgumentException();
        }
        if (driver != null) {
            driver.get(resourceBundle.getString("url"));
            driver.manage().window().maximize();
            logger.info("Browser opened and URL is launched - " + browser.toUpperCase() + " URL - " + resourceBundle.getString("url"));
        }
    }

    @After
    public void tearDown() {
        logger.info("Closing Browser session");
        if (driver != null)
            driver.quit();
    }
}
